/* THE GOLF LAB — content data (lessons, clubs, shot problems, practice plans).
   All directions assume a right-handed golfer. */
window.GL = window.GL || {};

GL.categories = [
  { id: 'setup',     name: 'Setup',      zh: '準備動作', desc: '握桿、站姿、姿勢與瞄準：每一桿開始前的四件事。' },
  { id: 'chipping',  name: 'Chipping',   zh: '切球',   desc: '果嶺邊的短距離，低飛行、多滾動。' },
  { id: 'putting',   name: 'Putting',    zh: '推桿',   desc: '短推穩定度、長推距離感與看線。' },
  { id: 'pitching',  name: 'Pitching',   zh: '劈起球', desc: '20–60 碼，需要飛越障礙的高球。' },
  { id: 'bunker',    name: 'Bunker',     zh: '沙坑',   desc: '果嶺邊沙坑一次出沙上果嶺。' },
  { id: 'fullswing', name: 'Full Swing', zh: '全揮桿', desc: '從起桿到收桿，鐵桿與木桿的完整揮桿。' }
];

/* Learn Golf is grouped into four units, in the order a beginner should learn them. */
GL.sections = [
  { id: 'setup', name: 'Setup', zh: '準備動作', cats: ['setup'], desc: '還沒揮桿就決定了一半的結果。先把握桿、站姿、姿勢與瞄準做對。' },
  { id: 'swing', name: 'Full Swing', zh: '全揮桿', cats: ['fullswing'], desc: '起桿、上桿、下桿、擊球到收桿，一步一步拆開來練。' },
  { id: 'short', name: 'Short Game', zh: '短桿', cats: ['chipping', 'pitching', 'bunker'], desc: '果嶺周圍的切球、劈起球與沙坑，最快省桿的地方。' },
  { id: 'putting', name: 'Putting', zh: '推桿', cats: ['putting'], desc: '短推、長推與看線，每一洞的最後一桿。' }
];

/* shot: illustration of the ball flight. air = share of the trip spent in the air,
   h = relative apex height, lie = what the ball sits on. */
GL.lessons = [
  { id: 'bump-and-run', cat: 'chipping', title: 'Bump & Run', zh: '低飛行、多滾動', level: '入門', mins: 6, featured: true, shot: {air: 0.22, h: 0.18, lie: 'fringe'}, soon: true },
  { id: 'standard-chip', cat: 'chipping', title: 'Standard Chip', zh: '基本切球', level: '入門', mins: 6, shot: {air: 0.4, h: 0.3, lie: 'fairway'}, soon: true },
  { id: 'putter-from-fringe', cat: 'chipping', title: 'Putter from Fringe', zh: '草面平順、無障礙時', level: '入門', mins: 4, featured: true, shot: {air: 0, h: 0, lie: 'fringe'}, soon: true },
  { id: 'pitch-shot', cat: 'pitching', title: 'Pitch Shot', zh: '較高飛行、較少滾動', level: '中級', mins: 8, featured: true, shot: {air: 0.7, h: 0.6, lie: 'fairway'}, soon: true },
  { id: 'flop-shot', cat: 'pitching', title: 'Flop Shot', zh: '高彈道、較快停球', level: '進階', mins: 8, featured: true, shot: {air: 0.9, h: 1, lie: 'rough'}, soon: true },
  { id: 'bunker-splash', cat: 'bunker', title: 'Splash Shot', zh: '果嶺邊沙坑爆炸球', level: '中級', mins: 7, shot: {air: 0.72, h: 0.7, lie: 'bunker'}, soon: true },
  { id: 'short-putts', cat: 'putting', title: 'Short Putts', zh: '1–2 公尺短推', level: '入門', mins: 6, featured: true, shot: {air: 0, h: 0, lie: 'green'}, soon: true },
  { id: 'lag-putting', cat: 'putting', title: 'Lag Putting', zh: '長推距離感', level: '入門', mins: 6, shot: {air: 0, h: 0, lie: 'green'}, soon: true },
  { id: 'green-reading', cat: 'putting', title: 'Reading Greens', zh: '看線與坡度', level: '中級', mins: 7, shot: {air: 0, h: 0, lie: 'green'}, soon: true },
  { id: 'iron-basics', cat: 'fullswing', title: 'Iron Basics', zh: '鐵桿基本揮桿', level: '入門', mins: 8, shot: {air: 0.85, h: 0.75, lie: 'fairway'}, soon: true }
];

/* Setup and full-swing lessons. art = which diagram to draw instead of a ball flight. */
GL.lessons = [
  {
    id: 'grip', cat: 'setup', title: 'The Grip', zh: '握桿', level: '入門', mins: 6, art: 'grip',
    situation: '所有全揮桿、切球與劈起球的基礎。雙手是你和球桿唯一的接觸點，握法決定擊球時桿面朝哪裡，很多右曲、左曲都是從握桿開始的。',
    club: { pick: '所有球桿（推桿除外）', note: '推桿的握法不同，請看 Short Putts。' },
    setup: [
      '左手：握把斜放在手指根部，從食指第二節斜到小指根部，不是放在掌心。',
      '左手拇指放在握把中線稍微偏右。往下看，可以看到左手 2–3 個指節。',
      '右手：同樣用手指握，右手掌心蓋住左手拇指。',
      '雙手虎口的「V」字都指向右肩附近。',
      '連接方式三選一：重疊式（右手小指疊在左手食指與中指之間）、互鎖式（右手小指與左手食指勾在一起）、十指式。手小的人可以試互鎖或十指式。'
    ],
    steps: [
      '桿頭平放在地上，桿面對準目標。',
      '左手從側面握上，確認握把在手指上。',
      '往下看檢查指節：2–3 個。',
      '右手蓋上，右手掌心朝向目標。',
      '握力大約 4/10：像拿著一條牙膏，不要把牙膏擠出來。'
    ],
    mistakes: [
      { m: '用掌心握', fix: '手腕無法自然折起，距離與力量都會流失。讓握把停在手指根部。' },
      { m: '握太緊', fix: '前臂緊繃、揮桿變慢。握力保持 4/10，揮桿中也不要突然抓緊。' },
      { m: '握桿太弱（只看到 0–1 個指節）', fix: '擊球時桿面容易打開，球往右飛。左手往右轉一點。' },
      { m: '握桿太強（看到 4 個指節）', fix: '桿面容易關閉，球往左彎。左手轉回來一點。' }
    ],
    drills: [
      { name: '鏡子檢查', how: '對著鏡子握桿，確認看到 2–3 個指節、兩個 V 字都指向右肩，每天練習握 10 次。' },
      { name: '握把畫線', how: '在練習用握把上貼一條膠帶標記左手拇指位置，每次握都放在同一個地方。' }
    ]
  },
  {
    id: 'stance', cat: 'setup', title: 'Stance & Ball Position', zh: '站姿與球位', level: '入門', mins: 6, art: 'stance',
    situation: '每一次揮桿前都要做。站姿寬度決定平衡與轉身，球位決定桿頭在什麼位置接觸球：球位錯了，再好的揮桿也會打厚、打薄或偏方向。',
    club: { pick: '依球桿調整寬度與球位', note: '球桿越長，站姿越寬、球位越靠左。' },
    setup: [
      '7 號鐵：雙腳內側與肩同寬。',
      'Driver：比肩膀稍寬；挖起桿：比肩膀稍窄。',
      '左腳尖往外打開約 20–30°，右腳尖可以稍微打開或垂直。',
      '球位：挖起桿在正中間；7 號鐵在中間偏左一顆球；球道木與 Hybrid 再往左一點；Driver 在左腳跟內側。',
      '重心平均落在雙腳腳掌中間，不在腳跟也不在腳尖。'
    ],
    steps: [
      '先站在球的正前方，雙腳併攏、球在兩腳中間。',
      '左腳往目標方向移動一小步，決定球位。',
      '右腳往後移動，打開到適合這支桿的寬度。',
      '輕輕彎曲膝蓋，感受重心在腳掌中間。'
    ],
    mistakes: [
      { m: '站太寬', fix: '髖部無法轉動，揮桿只剩手臂。全揮桿用 7 號鐵時與肩同寬就好。' },
      { m: '球位太靠左', fix: '容易打厚或球往左拉。鐵桿回到中間偏左一顆球。' },
      { m: '球位太靠右', fix: '容易打薄、球往右推。依球桿把球往左移。' },
      { m: '每次球位都不一樣', fix: '用「雙腳併攏再分開」的固定流程站位。' }
    ],
    drills: [
      { name: 'T 字球桿', how: '地上放一支球桿沿著腳尖，另一支垂直指向球位，換不同球桿時練習把球移到正確位置。' },
      { name: '併腳開步', how: '每顆球都從雙腳併攏開始，左腳一小步、右腳一大步，連續 20 次建立習慣。' }
    ]
  },
  {
    id: 'posture', cat: 'setup', title: 'Posture', zh: '姿勢', level: '入門', mins: 5, art: 'posture',
    situation: '站好之後、揮桿之前。好的姿勢讓身體可以自由轉動並保持平衡，揮桿時也比較不會起身或往前倒。',
    club: { pick: '所有全揮桿', note: '越長的球桿站得越直、離球越遠，但姿勢的原則相同。' },
    setup: [
      '從髖關節往前傾（像是用屁股往後推開一扇門），而不是彎腰。',
      '背部保持平直，上半身前傾約 30–40°。',
      '膝蓋輕微彎曲，不要蹲下。',
      '手臂從肩膀自然垂下，雙手和大腿之間大約一個拳頭的距離。',
      '下巴抬起，讓左肩可以在上桿時從下巴下方轉過去。'
    ],
    steps: [
      '站直，把球桿橫放在髖部前方。',
      '用球桿壓住髖部往後推，讓上半身往前傾。',
      '膝蓋微彎，重心移到腳掌中間。',
      '讓手臂自然垂下握桿，桿頭放到球後面。'
    ],
    mistakes: [
      { m: '彎腰駝背', fix: '轉身受限、容易打薄。想像背部是一塊平板。' },
      { m: '蹲太低', fix: '膝蓋只要輕微彎曲，像準備接球一樣。' },
      { m: '手伸得太遠', fix: '重心往前倒、容易打到桿頸。讓手臂垂直落下。' }
    ],
    drills: [
      { name: '球桿貼背', how: '把球桿貼在背後，碰到後腦、上背與尾椎三個點，從髖部前傾時三個點都不能離開球桿。' },
      { name: '鏡子側面', how: '從側面看鏡子，檢查肩膀、膝蓋與腳掌前緣是否大致在一條垂直線上。' }
    ]
  },
  {
    id: 'alignment', cat: 'setup', title: 'Alignment', zh: '瞄準', level: '入門', mins: 5, art: 'alignment',
    situation: '每一桿站位前。就算揮桿完美，瞄錯方向，球也到不了目標。大部分業餘球員都在不知不覺中瞄向目標右側。',
    club: { pick: '所有球桿', note: '推桿也用同樣的「軌道」概念。' },
    setup: [
      '想像一條鐵軌：外側軌道是球到目標的線，內側軌道是你的腳、髖部和肩膀。',
      '身體的線和目標線平行，所以身體其實是對準目標的「左邊」。',
      '先用桿面對準目標，再擺好雙腳。'
    ],
    steps: [
      '站在球的正後方，看著球和目標連成一條線。',
      '在球前方約 1 公尺的線上選一個「中間目標」（草的顏色、落葉、痕跡）。',
      '走到球旁，先把桿面對準中間目標。',
      '再讓雙腳、髖部、肩膀與這條線平行。',
      '揮桿前最後看一次目標，相信你的瞄準。'
    ],
    mistakes: [
      { m: '用雙腳直接對準目標', fix: '整個身體會瞄向目標右邊。身體要和目標線「平行」，不是對準目標。' },
      { m: '肩膀打開', fix: '腳是平行的但肩膀朝左，會導致由外往內的揮桿。檢查肩膀線。' },
      { m: '先站好才擺桿面', fix: '順序反了容易瞄偏。永遠先擺桿面。' }
    ],
    drills: [
      { name: '鐵軌球桿', how: '地上放兩支球桿：一支指向目標放在球外側，一支與它平行放在腳尖前，每次練習都放著。' },
      { name: '中間目標', how: '每一球都先選 1 公尺前的中間目標，再對準它擊球，養成固定的瞄準流程。' }
    ]
  },
  { id: 'backswing', cat: 'fullswing', title: 'Takeaway & Backswing', zh: '起桿與上桿', level: '入門', mins: 7, art: 'swing', phase: 'back', soon: true },
  { id: 'downswing', cat: 'fullswing', title: 'Downswing & Impact', zh: '下桿與擊球', level: '中級', mins: 7, art: 'swing', phase: 'down', soon: true },
  { id: 'finish-tempo', cat: 'fullswing', title: 'Finish & Tempo', zh: '收桿與節奏', level: '入門', mins: 5, art: 'swing', phase: 'finish', soon: true },
  { id: 'driver-basics', cat: 'fullswing', title: 'Driver Basics', zh: '一號木開球', level: '中級', mins: 7, shot: {air: 0.82, h: 0.55, lie: 'fairway'}, soon: true }
].concat(GL.lessons);
// keep Iron Basics ahead of Driver Basics inside the Full Swing unit
GL.lessons.splice(GL.lessons.map(function (l) { return l.id; }).indexOf('driver-basics'), 0,
  GL.lessons.splice(GL.lessons.map(function (l) { return l.id; }).indexOf('iron-basics'), 1)[0]);

GL.clubs = [
  {
    id: 'driver', name: 'Driver', zh: '一號木', type: 'driver', loftShow: 10.5,
    loft: '8°–12°', men: '200–250', women: '140–190', icon: 'driver',
    best: ['Par 4 / Par 5 開球', '寬闊的球道', '需要最大距離時'],
    pick: [
      '揮桿速度慢：選 10.5°–12° 較高 loft，更容易把球打高、飛遠。',
      '桿身硬度依揮速：< 75 mph L、75–85 A、85–95 R、95–105 S。',
      '新手選大頭（460cc）、高容錯的款式；可調式桿頭能慢慢微調。'
    ],
    tip: '只能用 Tee 打的桿，開球時 Tee 高度讓一半的球高於桿頭頂端。'
  },
  {
    id: 'wood', name: 'Fairway Wood', zh: '球道木桿', type: 'wood', loftShow: 15,
    loft: '15°–21°', men: '180–220', women: '120–160', icon: 'wood',
    best: ['Par 5 第二桿', '較窄球道的開球', '球道上的長距離'],
    pick: [
      '3 號木（15°）距離遠但較難；5 號木（18°）更容易打高，新手優先。',
      '選擇淺臉、低重心的桿頭，從草地上更容易起球。',
      '與 Driver 至少保持 20 碼的距離差。'
    ],
    tip: '從地面擊球時橫掃，而不是往下打。'
  },
  {
    id: 'hybrid', name: 'Hybrid', zh: '混合桿', type: 'hybrid', loftShow: 22,
    loft: '17°–27°', men: '160–200', women: '110–150', icon: 'hybrid',
    best: ['取代 3–5 號長鐵', '長草區救球', '果嶺邊的切滾'],
    pick: [
      '比對你想取代的鐵桿 loft：4 號鐵約 21°，就選 21°–22° 的 Hybrid。',
      '和球道木、最長的鐵桿之間各保持 10–15 碼距離差。',
      '揮速不快的球員，可以用 2 支 Hybrid 取代所有長鐵。'
    ],
    tip: '打法像鐵桿：球位在中間偏左，往下擊球。'
  },
  {
    id: 'iron', name: 'Irons', zh: '鐵桿（4–9）', type: 'iron', loftShow: 32,
    loft: '20°–45°', men: '120–190', women: '80–140', icon: 'iron',
    best: ['攻果嶺', 'Par 3 開球', '需要精準方向與距離時'],
    pick: [
      '新手選周邊配重、寬底的「易打型」鐵桿，容錯率高。',
      '每支鐵桿之間約差 4° loft、10–15 碼距離。',
      '做一次 Fitting 量 Lie 角度：太直或太平都會讓球偏左偏右。'
    ],
    tip: '號碼越大，loft 越高、桿身越短，距離越近。'
  },
  {
    id: 'wedge', name: 'Wedges', zh: '挖起桿 PW / GW / SW / LW', type: 'wedge', loftShow: 56,
    loft: '44°–60°', men: '40–130', women: '30–95', icon: 'wedge',
    best: ['100 碼內攻果嶺', '果嶺邊切球與劈起球', '沙坑'],
    pick: [
      '每支挖起桿之間相差 4°–6°，例如 PW 46° → 50° → 54° → 58°。',
      'Bounce 選擇：軟沙、鬆軟草地選高 Bounce（10°+）；硬地選低 Bounce（4°–8°）。',
      '新手先準備 PW + 56° 就足夠應付大部分短桿。'
    ],
    tip: '短桿占了一場球約 60% 的桿數，最值得花時間練習。'
  },
  {
    id: 'putter', name: 'Putter', zh: '推桿', type: 'putter', loftShow: 3,
    loft: '2°–4°', men: '—', women: '—', icon: 'putter',
    best: ['果嶺上', '平順的果嶺邊緣', '每一洞的最後一桿'],
    pick: [
      'Blade（刀背）：適合有弧度的推桿軌跡，手感細膩。',
      'Mallet（槌型）：慣性高、容錯好，適合直進直出的推法。',
      '長度通常 32–35 吋，站好後眼睛要在球的正上方。'
    ],
    tip: '在店裡試推 3 公尺：瞄準時是否覺得「直覺對準」最重要。'
  }
];

/* carry distances (yards) for the comparison scorecard */
GL.clubTable = [
  { c: 'DR', loft: '10.5', men: 230, women: 165 },
  { c: '3W', loft: '15', men: 210, women: 145 },
  { c: '5W', loft: '18', men: 195, women: 135 },
  { c: 'HY', loft: '22', men: 180, women: 125 },
  { c: '5i', loft: '26', men: 170, women: 120 },
  { c: '6i', loft: '29', men: 160, women: 110 },
  { c: '7i', loft: '33', men: 150, women: 100 },
  { c: '8i', loft: '37', men: 140, women: 92 },
  { c: '9i', loft: '41', men: 130, women: 85 },
  { c: 'PW', loft: '45', men: 115, women: 75 },
  { c: 'GW', loft: '50', men: 100, women: 65 },
  { c: 'SW', loft: '56', men: 85, women: 55 },
  { c: 'LW', loft: '60', men: 65, women: 45 }
];

/* Fix My Shot — fixed decision rules. Each answer adds weight to possible causes;
   the highest score is shown as the most likely cause. */
GL.problems = [
  {
    id: 'fat', title: '為什麼我一直打厚？', en: 'Fat shots', desc: '桿頭先打到地，球飛不遠。',
    questions: [
      { q: '最常在哪種擊球發生？', a: [
        { t: '果嶺邊切球', w: { scoop: 2, weight: 1 } },
        { t: '鐵桿全揮', w: { weight: 2, cast: 2 } },
        { t: '兩種都會', w: { weight: 1, scoop: 1, cast: 1 } }
      ]},
      { q: '擊球後，你的重心大多在哪隻腳？', a: [
        { t: '右腳（後腳）', w: { weight: 3 } },
        { t: '左腳（前腳）', w: { ball: 1, cast: 1 } },
        { t: '不確定', w: { weight: 1 } }
      ]},
      { q: '你的球位通常放在？', a: [
        { t: '偏左腳', w: { ball: 3 } },
        { t: '中間', w: {} },
        { t: '偏右腳', w: { cast: 1 } }
      ]},
      { q: '擊球時，你會不會想「把球撈起來」？', a: [
        { t: '會', w: { scoop: 3 } },
        { t: '不會', w: { cast: 1 } }
      ]}
    ],
    causes: {
      weight: { name: '重心留在後腳', why: '重心沒有移到左腳，揮桿最低點就會落在球的後方。', fix: '下桿時感覺左髖往目標移動，收桿時右腳跟離地。', drill: '在右腳下墊一顆球或毛巾，強迫重心留在左側。', lesson: 'iron-basics' },
      scoop: { name: '想把球撈起來', why: '手腕提早翻動試圖幫球飛起，桿頭在球前就碰到地面。', fix: '手保持在球前方，相信桿面的 loft 會讓球飛起。', drill: '硬幣最低點：在球前 5 公分放硬幣，每次都要擦過它。', lesson: 'standard-chip' },
      cast: { name: '提早放桿（Casting）', why: '下桿一開始就把手腕的角度放掉，桿頭太早到達最低點。', fix: '下桿時讓手領先，保持手腕角度到擊球前。', drill: '半揮停在 9 點鐘、送桿到 3 點鐘，檢查手是否領先桿頭。', lesson: 'iron-basics' },
      ball: { name: '球位太靠左', why: '球太前面，桿頭在碰到球前已經先碰到地。', fix: '鐵桿球位在中間偏左一顆球；切球在中間偏右。', drill: '在地上放一支球桿當參考線，固定每次的球位。', lesson: 'bump-and-run' }
    }
  },
  {
    id: 'thin', title: '為什麼我一直打薄？', en: 'Thin / topped shots', desc: '打到球的上半部，球貼地飛或滾。',
    questions: [
      { q: '球通常怎麼飛？', a: [
        { t: '低平、飛很遠', w: { scoop: 2, lift: 1 } },
        { t: '直接滾在地上', w: { lift: 3 } }
      ]},
      { q: '擊球時，你的身體會不會站起來？', a: [
        { t: '會，感覺往上', w: { lift: 3 } },
        { t: '不會', w: { scoop: 1, arms: 1 } },
        { t: '不確定', w: { lift: 1 } }
      ]},
      { q: '收桿時，左手肘的狀態？', a: [
        { t: '彎曲往外翹（雞翅膀）', w: { arms: 3 } },
        { t: '自然伸直', w: {} }
      ]},
      { q: '切球時，你想把球撈起來嗎？', a: [
        { t: '會', w: { scoop: 3 } },
        { t: '不會', w: {} }
      ]}
    ],
    causes: {
      lift: { name: '擊球時起身', why: '身體失去前傾角度、提早抬頭，桿頭的最低點也跟著變高。', fix: '保持胸口朝下直到擊球後，眼睛看著球原本的位置。', drill: '找人在你頭頂輕放一支球桿，揮桿時頭不要碰到它。', lesson: 'iron-basics' },
      scoop: { name: '撈球', why: '手腕在擊球前翻動，桿頭往上走，打到球的赤道。', fix: '手在球前方，桿身前傾；讓桿頭往下打。', drill: '毛巾在後：在球後 10 公分放毛巾，揮桿不能碰到它。', lesson: 'standard-chip' },
      arms: { name: '手臂縮起來（雞翅膀）', why: '擊球時手臂收縮，桿頭的弧度變短。', fix: '送桿時讓雙臂伸展，向目標延伸。', drill: '雙臂夾住一條毛巾揮半揮，保持手臂與身體一起轉。', lesson: 'iron-basics' }
    }
  },
  {
    id: 'slice', title: '為什麼我的球一直往右飛？', en: 'Slice / push', desc: '球向右彎或一開始就往右。',
    questions: [
      { q: '球的飛行路線比較像？', a: [
        { t: '先直，後面往右彎', w: { face: 2, path: 1 } },
        { t: '一開始就直直往右', w: { aim: 2, open: 2 } },
        { t: '先往左，再大幅向右彎', w: { path: 3, face: 1 } }
      ]},
      { q: '握桿後往下看，能看到左手幾個指節？', a: [
        { t: '0–1 個', w: { face: 3 } },
        { t: '2–3 個', w: { path: 1 } },
        { t: '不確定', w: { face: 1 } }
      ]},
      { q: '下桿的感覺比較像？', a: [
        { t: '肩膀先轉，從上往下「砍」', w: { path: 3 } },
        { t: '身體轉太快，手跟不上', w: { open: 3 } },
        { t: '沒什麼特別感覺', w: { aim: 1 } }
      ]},
      { q: '用 Driver 時特別嚴重嗎？', a: [
        { t: '是', w: { face: 1, path: 1 } },
        { t: '不是，每支桿都一樣', w: { aim: 2 } }
      ]}
    ],
    causes: {
      face: { name: '桿面打開（握桿太弱）', why: '擊球時桿面朝右，球產生右旋而向右彎。', fix: '左手往右轉一點，讓自己看到 2–3 個指節。', drill: '半揮練習：收桿時讓左手背朝下、右手翻到上面，感受桿面關閉。' },
      path: { name: '由外往內的揮桿路徑', why: '下桿從目標線外側切入，球帶著右旋向右彎。', fix: '下桿先讓右手肘貼近身體，感覺從身體內側往右外野揮。', drill: '在球外側放一個保特瓶，下桿不能碰到它。' },
      open: { name: '身體轉太快、桿面來不及關', why: '身體領先太多，手和桿面還留在後面，球被推向右邊。', fix: '下桿節奏放慢，讓手臂與身體同步到達。', drill: '腳併攏揮桿：減少下半身動作，讓手臂學會釋放。', lesson: 'iron-basics' },
      aim: { name: '瞄準與站位偏右', why: '雙腳和肩膀對準右邊，球就會自然往右飛。', fix: '先用桿面對準目標，再站好腳，肩膀與目標線平行。', drill: '練習時地上放兩支球桿：一支指目標，一支與腳尖平行。' }
    }
  },
  {
    id: 'hook', title: '為什麼我的球一直往左彎？', en: 'Hook / pull', desc: '球向左彎或一開始就往左。',
    questions: [
      { q: '球的飛行路線比較像？', a: [
        { t: '先往右，再大幅往左彎', w: { inout: 3 } },
        { t: '直直往左', w: { pull: 3 } },
        { t: '先直，後面往左彎', w: { strong: 2, flip: 1 } }
      ]},
      { q: '握桿後能看到左手幾個指節？', a: [
        { t: '3 個以上', w: { strong: 3 } },
        { t: '2 個', w: { flip: 1 } }
      ]},
      { q: '擊球時手腕的感覺？', a: [
        { t: '很用力翻轉', w: { flip: 3 } },
        { t: '自然', w: { inout: 1 } }
      ]}
    ],
    causes: {
      strong: { name: '握桿太強', why: '雙手轉太右，擊球時桿面容易關閉。', fix: '左手轉回來一點，看到 2 個指節即可。', drill: '鏡子檢查：握桿時左手虎口的 V 字指向右肩。' },
      flip: { name: '手腕過度翻轉', why: '擊球時手腕主動翻轉，桿面關得太快。', fix: '讓身體持續轉動帶球，而不是用手翻。', drill: '收桿停在 3 點鐘，檢查桿面是否指向天空的斜上方。' },
      inout: { name: '路徑太由內往外', why: '揮桿太往右外野，加上桿面關閉產生強烈左旋。', fix: '讓收桿更往左、往上，身體完整轉向目標。', drill: '在球內側後方放保特瓶，下桿不要太從內側切入。' },
      pull: { name: '由外往內 + 桿面關閉', why: '路徑往左、桿面也朝左，球直接往左飛。', fix: '下桿由下半身開始，不要先用肩膀轉。', drill: '在球外側放一個保特瓶，下桿不能碰到它。' }
    }
  },
  {
    id: 'shank', title: '為什麼我會打到腳跟（Shank）？', en: 'Shank', desc: '球打到桿頸，突然往右方飛出。',
    questions: [
      { q: '通常在哪種擊球發生？', a: [
        { t: '短桿與劈起球', w: { open: 2, close: 1 } },
        { t: '鐵桿全揮', w: { toes: 2, path: 2 } }
      ]},
      { q: '擊球時，重心會不會往腳尖移？', a: [
        { t: '會', w: { toes: 3 } },
        { t: '不會', w: { path: 1 } }
      ]},
      { q: '你是不是站得離球很近？', a: [
        { t: '是', w: { close: 3 } },
        { t: '不是', w: { path: 1, open: 1 } }
      ]}
    ],
    causes: {
      toes: { name: '重心往腳尖移動', why: '下桿時身體往前倒，桿頭被推向外側，用桿頸擊中球。', fix: '重心保持在腳掌中間，擊球時感覺腳跟壓地。', drill: '腳尖踩在一根球桿上揮桿，重心不能往前倒。' },
      close: { name: '站得離球太近', why: '桿頸的位置正好在球的上方。', fix: '站好後讓手臂自然垂下，手與大腿之間約一個拳頭寬。', drill: '每次站位前，先用桿頭量一個固定距離。' },
      path: { name: '揮桿路徑太往外', why: '下桿從外側切入，桿頸先到達球。', fix: '下桿讓手更靠近身體。', drill: '在球外側 3 公分放一顆球，只能打到內側那顆。' },
      open: { name: '短桿桿面打太開', why: '桿面打開時，桿頸會更靠近球。', fix: '短桿先用正面桿面練習，熟練後再打開。', drill: '用桿頭趾端（toe）擊球練習 10 顆，找回中心。', lesson: 'pitch-shot' }
    }
  },
  {
    id: 'putts', title: '為什麼短推總是推不進？', en: 'Missed short putts', desc: '1–2 公尺的推桿總是擦洞而過。',
    questions: [
      { q: '你通常錯在哪一側？', a: [
        { t: '總是右邊', w: { face: 2, aim: 1 } },
        { t: '總是左邊', w: { wrists: 2, aim: 1 } },
        { t: '兩邊都有，或推太短', w: { decel: 3 } }
      ]},
      { q: '推完會立刻抬頭看球嗎？', a: [
        { t: '會', w: { head: 3 } },
        { t: '不會', w: { aim: 1 } }
      ]},
      { q: '後擺和送桿哪個比較長？', a: [
        { t: '後擺較長', w: { decel: 3 } },
        { t: '差不多 / 送桿較長', w: { face: 1, aim: 1 } }
      ]}
    ],
    causes: {
      face: { name: '擊球時桿面打開', why: '1 公尺推桿，桿面差 2° 就會錯過洞。', fix: '雙手輕握，用肩膀推，桿面在送桿時持續朝向洞。', drill: 'Gate Drill：兩支 tee 只比推桿頭寬一點，推 20 顆不碰 tee。', lesson: 'short-putts' },
      wrists: { name: '手腕主導', why: '手腕翻動讓桿面關閉、球往左偏。', fix: '把握把貼在左前臂上練習，只用肩膀擺動。', drill: '單手推桿：只用左手推 10 顆 1 公尺。', lesson: 'short-putts' },
      decel: { name: '擊球前減速', why: '後擺太大、擊球時收力，桿面不穩、球也推不到洞。', fix: '後擺縮短，送桿長度是後擺的 1.5 倍。', drill: 'Circle Drill：1 公尺 8 顆，全部推過洞 30 公分。', lesson: 'short-putts' },
      head: { name: '提早抬頭', why: '頭一動，肩膀就跟著轉，推擊方向改變。', fix: '推完數「一、二」再抬頭，或用耳朵聽球進洞。', drill: '在球下放一枚硬幣，推完後要先看到硬幣再抬頭。', lesson: 'short-putts' },
      aim: { name: '瞄準偏差', why: '很多人站好後實際上瞄向洞的右側。', fix: '在球上畫一條線，先用線對準目標。', drill: '請朋友站在洞後方，檢查你的桿面是否真的對準洞。', lesson: 'green-reading' }
    }
  }
];

GL.plans = {};

/* Golf Rules — based on the Rules of Golf (R&A / USGA, 2023 edition).
   pen: 0 = no penalty, 1 = one stroke, 2 = two strokes (stroke play), 'x' = not a penalty question */
GL.ruleAreas = [
  { id: 'basics', name: 'Basics', zh: '基本規則', desc: '開始打球前要知道的事。' },
  { id: 'tee', name: 'Teeing Area', zh: '開球區', desc: '每一洞的第一桿。' },
  { id: 'general', name: 'General Area', zh: '一般區域', desc: '球道、長草區與樹林。' },
  { id: 'bunker', name: 'Bunker', zh: '沙坑', desc: '在沙裡能做與不能做的事。' },
  { id: 'penalty', name: 'Penalty Area', zh: '罰桿區', desc: '黃樁與紅樁：水域與其他罰桿區。' },
  { id: 'lost', name: 'Lost & Out of Bounds', zh: '遺失球與界外', desc: '找不到球或打出白樁。' },
  { id: 'green', name: 'Putting Green', zh: '果嶺', desc: '標記、清潔、修補與旗桿。' },
  { id: 'relief', name: 'Free Relief', zh: '免罰救濟', desc: '整修地、積水、步道與嵌入球。' }
];

GL.rules = [
  { area: 'basics', q: '球袋裡最多可以放幾支球桿？', a: '最多 14 支。開始一輪後發現多帶，每一洞罰 2 桿，一輪最多罰 4 桿，並且要立即宣告不使用多出的球桿。', pen: 2, rule: '4.1b' },
  { area: 'basics', q: '「依球的現況打球」是什麼意思？', a: '高爾夫最基本的原則：球停在哪裡就從哪裡打，不能改善球位、站位或揮桿空間，例如折斷樹枝、壓平草或移動固定物。違反時罰 2 桿。', pen: 2, rule: '8.1' },
  { area: 'basics', q: '不小心打到球兩次（Double hit）要罰桿嗎？', a: '不罰桿。只算一桿，然後從球停下的地方繼續打。', pen: 0, rule: '10.1a' },
  { area: 'basics', q: '打錯別人的球怎麼辦？', a: '比桿賽罰 2 桿，而且必須回去打自己的球來更正；用錯球打的桿數不算。比洞賽則輸掉這一洞。開球前在球上做記號可以避免這個問題。', pen: 2, rule: '6.3c' },
  { area: 'basics', q: '找球時不小心踢到自己的球呢？', a: '不罰桿。把球放回原位（不知道原位就估計位置）。', pen: 0, rule: '7.4' },
  { area: 'basics', q: '比桿賽與比洞賽有什麼不同？', a: '比桿賽（Stroke Play）把 18 洞的總桿數加起來，最少者勝；比洞賽（Match Play）每一洞分勝負，贏最多洞者勝。同一種違規，比洞賽通常是「輸掉該洞」而不是罰 2 桿。', pen: 'x', rule: '3' },

  { area: 'tee', q: '球可以放在開球區的哪裡？', a: '在兩個 Tee 標記之間、往後兩支球桿長度內的長方形範圍內。人可以站在範圍外，但球必須在範圍內。', pen: 'x', rule: '6.2b' },
  { area: 'tee', q: '在開球區外開球會怎樣？', a: '比桿賽罰 2 桿，並且必須從開球區內重打（第一次的那一桿不算）。比洞賽則由對手決定是否要你重打，不罰桿。', pen: 2, rule: '6.1b' },
  { area: 'tee', q: '還沒揮桿，球就從 Tee 上掉下來？', a: '不罰桿，放回 Tee 上重新開球即可。如果是在揮桿時打空，就算一桿。', pen: 0, rule: '6.2b' },

  { area: 'general', q: '球在長草裡，可以把草壓平再打嗎？', a: '不行。不可以改善影響擊球的狀況。可以正常站位並瞄球，但刻意壓平草、折斷樹枝都罰 2 桿。', pen: 2, rule: '8.1a' },
  { area: 'general', q: '可以移開球旁邊的落葉、小石頭嗎？', a: '可以。鬆散自然物（落葉、樹枝、石頭）在任何地方都可以移開，但如果移開時讓球移動了，罰 1 桿並把球放回原位（果嶺上除外）。', pen: 0, rule: '15.1' },
  { area: 'general', q: '球打不了（卡在樹下、樹叢裡）怎麼辦？', a: '你可以宣告「無法打球」，罰 1 桿後選一種方式：① 回到上一桿的位置重打；② 在球與旗桿的連線上往後任意距離拋球；③ 在球的位置兩支球桿長度內、不靠近洞的範圍拋球。', pen: 1, rule: '19.2' },
  { area: 'general', q: '球陷進自己打出的坑裡（嵌入球）？', a: '在一般區域可以免罰救濟：在球的正後方點，一支球桿長度內、不靠近洞的範圍拋球。沙坑內不適用。', pen: 0, rule: '16.3' },

  { area: 'bunker', q: '在沙坑瞄球時可以讓球桿碰到沙嗎？', a: '不行。瞄球、試揮或後擺時桿頭碰到沙，罰 2 桿。擊球時才可以入沙。', pen: 2, rule: '12.2b' },
  { area: 'bunker', q: '可以移開沙坑裡的落葉或石頭嗎？', a: '可以（2019 年起）。鬆散自然物與可移動的障礙物（例如耙子）都可以移開，但不要讓球移動。', pen: 0, rule: '12.2a' },
  { area: 'bunker', q: '沙坑裡的球打不了怎麼辦？', a: '罰 1 桿：回上一桿位置重打、在沙坑內往後拋球，或在沙坑內兩支球桿長度內拋球。或者罰 2 桿，在沙坑「外」沿著球與旗桿的連線往後拋球。', pen: 1, rule: '19.3' },
  { area: 'bunker', q: '打完要做什麼？', a: '把你留下的腳印與擊球痕跡耙平，並把耙子放回原處。這是禮儀，不是罰則，但非常重要。', pen: 'x', rule: '禮儀' },

  { area: 'penalty', q: '黃樁和紅樁有什麼差別？', a: '兩者都是罰桿區。黃樁罰 1 桿可以：回上一桿重打，或沿著球「最後越過邊界的點」與旗桿的連線往後拋球。紅樁多了一個選擇：在越過邊界點的兩支球桿長度內、不靠近洞的範圍拋球。', pen: 1, rule: '17.1d' },
  { area: 'penalty', q: '可以直接從罰桿區裡把球打出來嗎？', a: '可以，不罰桿。2019 年起，在罰桿區裡瞄球時桿頭可以碰地、碰水，也可以移開鬆散自然物。', pen: 0, rule: '17.1b' },
  { area: 'penalty', q: '球打進水裡但沒看到確切位置？', a: '必須「已知或幾乎確定」球在罰桿區內，才能用罰桿區的救濟。如果不確定，就要當作遺失球處理（回上一桿位置重打）。', pen: 1, rule: '17.1c' },

  { area: 'lost', q: '找球可以找多久？', a: '3 分鐘。從你（或球童）開始找的時候計算，3 分鐘內沒找到就是遺失球。', pen: 'x', rule: '18.2a' },
  { area: 'lost', q: '球遺失或打出界（白樁）怎麼辦？', a: '「桿數加距離」：罰 1 桿，回到上一桿的位置重打。例如開球出界，重新開球時是打第 3 桿。', pen: 1, rule: '18.2b' },
  { area: 'lost', q: '什麼是暫定球（Provisional ball）？', a: '覺得球可能遺失或出界（但不是在罰桿區）時，先宣告「我打一顆暫定球」再打第二顆，可以省下走回來的時間。找到原球就繼續打原球；找不到就用暫定球，罰 1 桿。', pen: 1, rule: '18.3' },
  { area: 'lost', q: '朋友說出界可以在球道拋球罰 2 桿？', a: '這是「當地規則 E-5」，只有球場或比賽公告採用時才可以：罰 2 桿，在球遺失或出界附近的球道邊拋球。是給休閒球友加快速度用的，正式比賽通常不採用。', pen: 2, rule: '當地規則 E-5' },

  { area: 'green', q: '果嶺上可以拿起球擦乾淨嗎？', a: '可以。先在球的正後方放球標，再拿起來清潔，然後放回原位。', pen: 0, rule: '13.1b' },
  { area: 'green', q: '推桿時可以不拔旗桿嗎？', a: '可以（2019 年起）。旗桿留在洞裡，球打到旗桿不罰桿，球停在洞裡就算進洞。', pen: 0, rule: '13.2a' },
  { area: 'green', q: '在果嶺上推球打到別人的球？', a: '比桿賽中，兩顆球都在果嶺上時，打到別人的球罰 2 桿。對方的球放回原位，你的球從停下的位置繼續打。推桿前請對方先標記。', pen: 2, rule: '11.1a' },
  { area: 'green', q: '可以修補果嶺上的球痕與釘鞋痕嗎？', a: '可以。2019 年起，果嶺上的任何損壞（球痕、釘鞋痕、動物痕跡）都可以修補，但不能修補自然的凹凸或磨損。', pen: 0, rule: '13.1c' },
  { area: 'green', q: '球掛在洞邊，可以等它掉下去嗎？', a: '走到洞邊後可以再等 10 秒。10 秒內掉進去就算上一桿進洞；10 秒後才掉進去，要多加 1 桿。', pen: 1, rule: '13.3a' },

  { area: 'relief', q: '球停在電車道或灑水頭旁邊？', a: '這是不可移動的障礙物，可以免罰救濟。找出「完全救濟的最近點」，在一支球桿長度內、不靠近洞的範圍拋球。也可以選擇照打。', pen: 0, rule: '16.1' },
  { area: 'relief', q: '整修地（GUR）、臨時積水怎麼處理？', a: '和障礙物一樣，可以免罰救濟：完全救濟的最近點，一支球桿長度內拋球。整修地通常用藍樁或白線標示。', pen: 0, rule: '16.1' },
  { area: 'relief', q: '怎麼拋球才正確？', a: '從膝蓋的高度直接放下，球必須落在救濟範圍內並停在範圍內。如果滾出範圍，重拋一次；再滾出去，就把球放在第二次落地的地方。', pen: 0, rule: '14.3' },
  { area: 'relief', q: '「一支球桿長度」用哪一支桿量？', a: '球袋裡最長的球桿，推桿除外（通常是 Driver）。兩支球桿長度就量兩次。', pen: 'x', rule: '定義' }
];

GL.penaltyTable = [
  ['揮桿打空', '算 1 桿'], ['不小心打到球兩次', '免罰'], ['果嶺上打到旗桿', '免罰'],
  ['找球時踢到自己的球', '免罰'], ['遺失球 / 界外', '1 桿 + 回上一桿'], ['黃樁 / 紅樁罰桿區', '1 桿'],
  ['無法打球', '1 桿'], ['沙坑瞄球碰沙', '2 桿'], ['打錯球', '2 桿'],
  ['在開球區外開球', '2 桿'], ['果嶺上打到別人的球', '2 桿'], ['超過 14 支球桿', '每洞 2 桿（最多 4 桿）']
];

GL.scoreTerms = [
  { t: 'Albatross', zh: '信天翁', d: '低於標準桿 3 桿（Par 5 打 2 桿）', v: '-3', sym: 'dcircle' },
  { t: 'Eagle', zh: '老鷹', d: '低於標準桿 2 桿', v: '-2', sym: 'dcircle' },
  { t: 'Birdie', zh: '博蒂（小鳥）', d: '低於標準桿 1 桿', v: '-1', sym: 'circle' },
  { t: 'Par', zh: '標準桿', d: '剛好打出標準桿', v: 'E', sym: '' },
  { t: 'Bogey', zh: '柏忌', d: '高於標準桿 1 桿', v: '+1', sym: 'square' },
  { t: 'Double Bogey', zh: '雙柏忌', d: '高於標準桿 2 桿', v: '+2', sym: 'dsquare' },
  { t: 'Hole in One', zh: '一桿進洞', d: '開球直接進洞，通常在 Par 3', v: '1', sym: 'circle' }
];

GL.etiquette = [
  ['安全第一', '揮桿前確認周圍沒有人；球可能打到別人時，大聲喊「Fore!」。'],
  ['保持速度', '輪到你時就準備好打（Ready golf），每一桿盡量在 40 秒內完成；後組等你時讓他們先過。'],
  ['愛護球場', '把草皮放回或補沙、耙平沙坑、修補果嶺上的球痕。'],
  ['尊重推桿線', '不要踩到別人球與洞之間的推桿線，別人擊球時保持安靜、不要站在對方視線內。'],
  ['誠實計分', '高爾夫靠自己判罰，打完一洞立刻記下自己的桿數。']
];
