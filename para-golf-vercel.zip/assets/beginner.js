/* PAR/A — content for beginners (new to golf, up to about 95 strokes):
   key points per lesson, glossary, 4-week paths, starter set, extra diagnoses and range practice plans. */
(function (GL) {
  'use strict';

  /* One-line takeaway shown at the top of each lesson. */
  var KEYS = {
    'grip': '用手指握、不是手掌；往下看到 2–3 個指節，握力只要 4/10。',
    'stance': '7 號鐵與肩同寬；桿越長、站越寬、球越靠左。',
    'posture': '從髖部前傾、背打直、膝微彎，手臂自然垂下。',
    'alignment': '先擺桿面、再擺身體；身體和目標線平行，不是對準目標。',
  };
  GL.lessons.forEach(function (l) { if (KEYS[l.id]) l.key = KEYS[l.id]; });

  /* Glossary. auto: also turn this word into a tappable term inside lessons and other text. */
  GL.glossary = [
    { g: '計分', t: 'Par', zh: '標準桿', d: '一個洞預期要打的桿數，通常是 3、4 或 5 桿。18 洞加起來多半是 72 桿。', auto: ['標準桿'] },
    { g: '計分', t: 'Birdie', zh: '博蒂（小鳥）', d: '比標準桿少 1 桿。' },
    { g: '計分', t: 'Bogey', zh: '柏忌', d: '比標準桿多 1 桿。新手的第一個目標可以是「每洞柏忌」，全場大約 90 桿。' },
    { g: '計分', t: 'Double Bogey', zh: '雙柏忌', d: '比標準桿多 2 桿。' },
    { g: '計分', t: 'Handicap', zh: '差點', d: '代表你平均比標準桿多打幾桿的數字，讓不同程度的人可以公平比賽。差點 28 大約是平均打 100 桿。', auto: ['差點'] },
    { g: '計分', t: 'Break 100', zh: '破百', d: '18 洞打進 99 桿以內，是許多新手的第一個里程碑。' },
    { g: '球場', t: 'Tee Box', zh: '開球區（發球台）', d: '每一洞第一桿的地方，用兩個 Tee 標記劃出範圍。', auto: ['開球區'] },
    { g: '球場', t: 'Fairway', zh: '球道', d: '開球區到果嶺之間、草剪得比較短的區域。球停在這裡最好打。', auto: ['球道'] },
    { g: '球場', t: 'Rough', zh: '長草區', d: '球道兩側草比較長的地方，球容易陷進去，比較難打。', auto: ['長草'] },
    { g: '球場', t: 'Green', zh: '果嶺', d: '洞所在的地方，草剪得最短，只用推桿。', auto: ['果嶺'] },
    { g: '球場', t: 'Fringe', zh: '果嶺邊緣', d: '果嶺外圍一圈稍長的草。', auto: ['果嶺邊緣'] },
    { g: '球場', t: 'Bunker', zh: '沙坑', d: '球場上裝沙的凹地。在沙坑裡瞄球時球桿不能碰到沙。', auto: ['沙坑'] },
    { g: '球場', t: 'Penalty Area', zh: '罰桿區', d: '用黃樁或紅樁標示的區域，通常是水。球進去後可以罰 1 桿救濟。', auto: ['罰桿區'] },
    { g: '球場', t: 'OB (Out of Bounds)', zh: '界外', d: '白樁外面的區域。球打出界要罰 1 桿，回上一桿的位置重打。', auto: ['界外', 'OB'] },
    { g: '球桿', t: 'Loft', zh: '桿面角度', d: '桿面往後傾斜的角度。Loft 越大，球飛得越高、越近。Driver 約 10°，挖起桿約 50–60°。', auto: ['Loft'] },
    { g: '球桿', t: 'Bounce', zh: '反彈角', d: '挖起桿桿底的角度，讓桿頭在沙或軟草上滑過去而不會挖太深。', auto: ['Bounce'] },
    { g: '球桿', t: 'Lie Angle', zh: '桿身角度', d: '桿身和地面的角度。不適合你的身高時，球容易偏左或偏右。', auto: ['Lie'] },
    { g: '球桿', t: 'Shaft Flex', zh: '桿身硬度', d: '桿身的軟硬：L（女士）、A（年長）、R（一般）、S（硬）。揮速慢的人用軟一點的桿身。', auto: ['桿身硬度'] },
    { g: '球桿', t: 'Hybrid', zh: '混合桿', d: '介於木桿和鐵桿之間，比長鐵桿更容易打高，很適合新手。', auto: ['Hybrid'] },
    { g: '球桿', t: 'Wedge', zh: '挖起桿', d: 'Loft 最大的鐵桿：PW、GW、SW、LW，用在短距離與沙坑。', auto: ['挖起桿'] },
    { g: '擊球', t: 'Fat', zh: '打厚', d: '桿頭先打到地面才打到球，球飛不遠。', auto: ['打厚'] },
    { g: '擊球', t: 'Thin / Top', zh: '打薄', d: '桿頭打到球的上半部，球低飛或在地上滾。', auto: ['打薄'] },
    { g: '擊球', t: 'Slice', zh: '右曲球', d: '（右手球員）球往右大幅彎曲，是新手最常見的球路。', auto: ['右曲'] },
    { g: '擊球', t: 'Hook', zh: '左曲球', d: '（右手球員）球往左大幅彎曲。', auto: ['左曲'] },
    { g: '擊球', t: 'Shank', zh: '打到桿頸', d: '球打到桿頭和桿身的連接處，突然往右側飛出去。', auto: ['Shank'] },
    { g: '擊球', t: 'Divot', zh: '草皮痕', d: '鐵桿擊球後被削起的一小片草皮。好的鐵桿擊球，草皮痕在球的前方。', auto: ['草皮痕'] },
    { g: '擊球', t: 'Sweet Spot', zh: '甜蜜點', d: '桿面正中央最有效率的擊球點。打中時手感最輕、距離最遠。' },
    { g: '統計', t: 'GIR', zh: '標準桿上果嶺', d: 'Greens in Regulation：在「標準桿 − 2」桿內上果嶺，例如 Par 4 用 2 桿上果嶺。', auto: ['GIR', '標準桿上果嶺'] },
    { g: '統計', t: 'Fairway Hit', zh: '開球上球道', d: 'Par 4 與 Par 5 的開球停在球道上的比例。' },
    { g: '統計', t: 'Up & Down', zh: '救球（兩桿進洞）', d: '沒上果嶺時，一次切球加一次推桿就進洞。', auto: ['Up & Down'] },
    { g: '統計', t: 'Scrambling', zh: '救球率', d: '沒有標準桿上果嶺時，仍然打出標準桿或更好的比例。', auto: ['Scrambling'] },
    { g: '統計', t: 'Sand Save', zh: '沙坑救球', d: '從果嶺邊沙坑出來後，一推內進洞的比例。' },
    { g: '統計', t: '3-Putt', zh: '三推', d: '在果嶺上推了 3 桿以上。新手最容易省桿的地方。', auto: ['三推'] },
    { g: '規則', t: 'Penalty Stroke', zh: '罰桿', d: '違反規則或救濟時要加上的桿數，例如出界、進水各罰 1 桿。', auto: ['罰桿'] },
    { g: '規則', t: 'Provisional Ball', zh: '暫定球', d: '覺得球可能遺失或出界時，先宣告再多打一顆，省下走回來的時間。', auto: ['暫定球'] },
    { g: '規則', t: 'Drop', zh: '拋球', d: '救濟時從膝蓋高度讓球落下，球要停在救濟範圍內。', auto: ['拋球'] },
    { g: '規則', t: 'Free Relief', zh: '免罰救濟', d: '球停在電車道、整修地等地方時，可以不罰桿移到旁邊打。', auto: ['免罰救濟'] },
    { g: '規則', t: 'Ready Golf', zh: '準備好就打', d: '休閒打球時，誰準備好誰先打，不一定要等最遠的人，讓速度變快。', auto: ['Ready golf'] },
    { g: '規則', t: 'Max Score', zh: '每洞上限', d: '新手休閒打球時，可以打到「雙倍標準桿」就把球撿起來，記下那個桿數，不拖慢後面的人。' }
  ];

  /* 4-week paths by starting point. Each item is a lesson or a page link. */
  GL.levels = [
    { id: 'new', t: '從沒摸過球桿', s: '還沒去過練習場，或只去過一兩次' },
    { id: 'range', t: '去過練習場，還沒下場', s: '可以把球打出去，但不穩定' },
    { id: 'course', t: '下過場，大約 100 桿以上', s: '目標是穩定破百、打進 95' }
  ];
  var L = function (id) { return { lesson: id }; };
  var P = function (href, t, s) { return { href: href, t: t, s: s }; };
  GL.paths = {
    new: [
      { w: '第 1 週', t: '認識球桿與準備動作', items: [P('guide.html#range', '第一次去練習場', '要帶什麼、怎麼買球、練習順序'), P('clubs.html#starter', '新手第一套球桿', '只需要 5–7 支'), L('grip'), L('stance'), L('posture'), L('alignment'), P('practice.html#b40', '新手練習場 40 分鐘', '照著菜單練一次')] },
      { w: '第 2 週', t: '半揮桿，打到球', items: [L('backswing'), L('downswing'), L('iron-basics'), P('fix.html#air', '球飛不起來？', '新手最常見的問題'), P('practice.html#b40', '新手練習場 40 分鐘', '這週練兩次')] },
      { w: '第 3 週', t: '完整揮桿與短桿', items: [L('finish-tempo'), L('bump-and-run'), L('short-putts'), P('practice.html#p30', '推桿 30 分鐘', '這週練一次')] },
      { w: '第 4 週', t: '準備第一次下場', items: [P('guide.html#course', '第一次下場', '服裝、時間、要帶什麼'), P('guide.html#score', '計分卡怎麼填', '每洞最多記雙倍標準桿'), P('rules.html#basics', '基本規則', '最常遇到的幾條'), L('driver-basics'), L('lag-putting')] }
    ],
    range: [
      { w: '第 1 週', t: '檢查基本功', items: [L('grip'), L('stance'), L('posture'), L('alignment'), P('fix.html', '擊球診斷', '找出你最常見的問題')] },
      { w: '第 2 週', t: '揮桿順序與節奏', items: [L('backswing'), L('downswing'), L('finish-tempo'), L('iron-basics'), P('practice.html#r60', '練習場 60 分鐘', '完整的練習菜單')] },
      { w: '第 3 週', t: '果嶺周圍', items: [L('bump-and-run'), L('standard-chip'), L('short-putts'), L('lag-putting'), P('practice.html#c30', '切球 30 分鐘', '落點、選桿與 Up & Down')] },
      { w: '第 4 週', t: '第一次下場', items: [P('guide.html#course', '第一次下場', '服裝、時間、要帶什麼'), P('guide.html#score', '計分卡怎麼填', '每洞最多記雙倍標準桿'), P('rules.html', '高球規則', '依球的位置查規則'), L('driver-basics'), P('shot.html', '短桿選擇', '果嶺邊不知道怎麼打時')] }
    ],
    course: [
      { w: '第 1 週', t: '找出漏掉的桿數', items: [P('my-game.html', '輸入一場成績', '用新手模式看看桿數掉在哪'), P('fix.html', '擊球診斷', '最常出現的失誤'), P('guide.html#score', '每洞上限', '避免一洞打到十幾桿')] },
      { w: '第 2 週', t: '少掉三推', items: [L('lag-putting'), L('short-putts'), L('green-reading'), P('practice.html#p30', '推桿 30 分鐘', '短推、距離感與看線一次練到')] },
      { w: '第 3 週', t: '果嶺周圍兩桿進洞', items: [L('bump-and-run'), L('standard-chip'), L('putter-from-fringe'), P('shot.html', '短桿選擇', '選最簡單的打法'), P('practice.html#updown', 'Up & Down 挑戰', '9 站計分卡')] },
      { w: '第 4 週', t: '避免大數字', items: [L('driver-basics'), L('bunker-splash'), P('rules.html#lost', '遺失球與界外', '正確處理罰桿'), P('practice.html#r60', '練習場 60 分鐘', '開球與鐵桿')] }
    ]
  };

  /* A beginner's first set. */
  GL.starterSet = [
    { c: '7 號鐵', need: '必備', d: '最好練習的一支桿，練習場大部分時間都用它。' },
    { c: 'PW 劈起桿', need: '必備', d: '100 碼內攻果嶺與果嶺邊切球。' },
    { c: '56° 沙坑桿', need: '必備', d: '沙坑和需要讓球飛高的短桿。' },
    { c: '推桿', need: '必備', d: '每一洞都會用到，選瞄準時覺得順眼的。' },
    { c: 'Hybrid 或 5 號木', need: '建議', d: '取代難打的長鐵，第二桿需要距離時用。' },
    { c: '9 號、5 號鐵', need: '建議', d: '補足 7 號鐵前後的距離。' },
    { c: 'Driver', need: '之後再買', d: '最難打的球桿。剛開始可以用 Hybrid 或 5 號木開球。' }
  ];

  /* Diagnoses beginners need most. */
  GL.problems.push(
    {
      id: 'whiff', title: '為什麼我會揮空、打不到球？', en: 'Whiff', desc: '揮桿時桿頭完全沒碰到球。',
      questions: [
        { q: '揮空時，桿頭經過球的哪裡？', a: [{ t: '從球的上方掃過', w: { lift: 3 } }, { t: '先打到球後面的地', w: { sway: 2, force: 1 } }, { t: '不確定', w: { force: 2 } }] },
        { q: '揮桿時你是不是很用力？', a: [{ t: '是，想打很遠', w: { force: 3 } }, { t: '不會', w: { lift: 1, setup: 1 } }] },
        { q: '揮桿時身體會左右晃動嗎？', a: [{ t: '會', w: { sway: 3 } }, { t: '不會', w: { setup: 2 } }, { t: '不確定', w: { sway: 1 } }] }
      ],
      causes: {
        lift: { name: '擊球時起身抬頭', why: '還沒打到球就抬頭看球去哪，身體跟著站起來，桿頭也被拉高。', fix: '眼睛盯著球，打完後再看。保持膝蓋與上半身的角度。', drill: '在球下方放一枚硬幣，擊球後還要看到硬幣才抬頭。', lesson: 'posture' },
        force: { name: '太用力', why: '想打遠時全身繃緊，動作變形，桿頭的路線就不穩定。', fix: '先用 50% 的力量、半揮桿把球打到就好，距離之後會自然出來。', drill: '9 點到 3 點的半揮，連續 10 顆都打到球再加大擺幅。', lesson: 'finish-tempo' },
        sway: { name: '身體左右晃動', why: '上桿時身體往右滑、下桿又往左衝，最低點每次都不一樣。', fix: '在原地轉身，想像腳下有一個圓圈，身體不能離開它。', drill: '雙腳併攏揮半揮桿，強迫自己在原地轉。', lesson: 'backswing' },
        setup: { name: '站的距離不對', why: '離球太遠或太近，手臂在擊球時伸直或縮起，桿頭就碰不到球。', fix: '手臂自然垂下握桿，手和大腿之間約一個拳頭。', drill: '每球站位前先檢查「一個拳頭」的距離。', lesson: 'posture' }
      }
    },
    {
      id: 'air', title: '為什麼球飛不起來，一直滾地？', en: 'Ball won’t get airborne', desc: '球貼著地面滾，或飛得很低。',
      questions: [
        { q: '最常發生在哪種球桿？', a: [{ t: '長鐵桿、木桿', w: { club: 3 } }, { t: '每一支都會', w: { scoop: 1, top: 1 } }] },
        { q: '球被打到哪裡？', a: [{ t: '上半部，球直接滾在地上', w: { top: 3 } }, { t: '飛很低、但有往前', w: { scoop: 2 } }, { t: '不知道', w: { scoop: 1, top: 1 } }] },
        { q: '擊球時，你會想把球「撈」起來嗎？', a: [{ t: '會', w: { scoop: 3 } }, { t: '不會', w: { top: 1, club: 1 } }] }
      ],
      causes: {
        scoop: { name: '想把球撈起來', why: '用手腕往上撈，桿頭在最低點之前就往上走，反而打到球的中間。', fix: '鐵桿要「往下」打，讓桿面的角度（Loft）把球送上去。', drill: '在球後方 10 公分放毛巾，揮桿不能碰到毛巾。', lesson: 'iron-basics' },
        top: { name: '擊球時起身（打頂）', why: '身體在擊球時站起來，桿頭跟著變高，打到球的上半部。', fix: '保持前傾角度到擊球後，眼睛盯著球。', drill: '半揮桿練習，收桿時胸口還朝向地面。', lesson: 'posture' },
        club: { name: '球桿太難打', why: '長鐵桿 Loft 小、桿身長，新手本來就很難把它打高。', fix: '用 Hybrid 或 5 號木取代 3–5 號鐵，Driver 的 Tee 放高一點。', drill: '練習時先用 7 號鐵打到穩定，再換長的球桿。', lesson: 'driver-basics' }
      }
    },
    {
      id: 'distance', title: '為什麼同一支桿距離每次都不一樣？', en: 'Inconsistent distance', desc: '有時很遠、有時很近。',
      questions: [
        { q: '擊球的手感？', a: [{ t: '常常震手、不紮實', w: { contact: 3 } }, { t: '手感還好', w: { tempo: 1, length: 1 } }] },
        { q: '你的揮桿速度？', a: [{ t: '每次都不太一樣', w: { tempo: 3 } }, { t: '差不多', w: { length: 1, contact: 1 } }] },
        { q: '你的上桿長度？', a: [{ t: '有時長、有時短', w: { length: 3 } }, { t: '差不多', w: { contact: 1, tempo: 1 } }] }
      ],
      causes: {
        contact: { name: '沒有打到甜蜜點', why: '打在桿頭的趾端或跟部，距離會差 10–20%。', fix: '先用半揮桿找到穩定的擊球點，再慢慢加大。', drill: '在桿面貼擊球貼紙或噴一點粉，看每一球打在哪裡。', lesson: 'iron-basics' },
        tempo: { name: '節奏不穩定', why: '有時候特別用力，速度與擊球點都會跟著改變。', fix: '固定的「一、二、三、打」節奏，力量 80%。', drill: '手機節拍器練習，三拍上桿、一拍下桿。', lesson: 'finish-tempo' },
        length: { name: '上桿長度不固定', why: '擺幅不同，距離自然不同。', fix: '每一支桿都揮到相同的頂點位置。', drill: '頂點停 2 秒檢查位置，再下桿。', lesson: 'backswing' }
      }
    }
  );

  /* Lessons announced but not written yet: shown as "coming soon" cards in their category. */
  GL.soon = {
    putting: [{ title: 'AimPoint', sub: '用腳感覺坡度的看線方法', shot: { lie: 'green', air: 0, curve: .32 } }]
  };

  /* Warm-up and practice swings: do this before any session, and before a round. */
  GL.plans.w10 = {
    name: 'Warm-up & Practice Swings', zh: '暖身與空揮 10 分鐘', boxed: true,
    why: {
      title: '為什麼要先暖身？',
      intro: '很多人一到練習場就拿起球桿全力打，結果前二十顆球都在亂飛，打完腰還痠。花 10 分鐘暖身，整場練習會差很多。',
      items: [
        ['比較不會受傷', '揮桿要大幅度轉動腰、背和肩膀。肌肉還是冷的時候突然全力揮，最容易拉傷下背和手肘。'],
        ['轉得開，才不會只用手打', '身體暖了，上桿肩膀才轉得夠，揮桿自然比較順、比較有力。'],
        ['先找到擊球點', '空揮時讓桿頭每次刷到同一個位置，等於先告訴身體「最低點在這裡」，開始打球後比較不會打厚、打薄。'],
        ['不浪費一開始的球', '前幾顆通常最亂。先暖身，第一顆球就能認真練，也不會一開始就打壞心情。']
      ],
      tip: '下場前也一樣：在開球台旁邊做第 1、2、5 項，大約 5 分鐘就夠了。'
    },
    blocks: [
      { mins: 1, cat: 'Warm-up', name: '動一動：身體熱起來', how: '原地快走或小跑 30 秒。手臂前後繞圈各 10 次，再雙手握住球桿兩端舉過頭，往左、往右側彎各 5 次。', fig: 'loosen', cap: '左：手臂往前、往後畫大圓。右：球桿舉過頭，身體往旁邊彎。' },
      { mins: 2, cat: 'Warm-up', name: '轉體：球桿放肩上', how: '把球桿橫放在肩膀前方、雙手交叉扶住，擺好站姿、從髖部前傾。慢慢往後轉、往前轉各 10 次，下半身盡量穩住。', fig: 'turn', cap: '肩膀轉、下半身穩住。上桿時左肩轉到下巴下方。' },
      { mins: 2, cat: 'Warm-up', name: '髖部與腿', how: '一手扶著球桿當支撐，單腳前後擺腿各 10 次，再做 10 次慢慢的深蹲。', fig: 'legs', cap: '左：扶著球桿，腳像鐘擺一樣前後擺。右：屁股往後坐，膝蓋不要超過腳尖太多。' },
      { mins: 1, cat: 'Warm-up', name: '開髖：開門式', how: '一手扶著球桿站穩，把一隻腳的膝蓋抬到大約 90 度，再慢慢往外打開，然後放下。左右腳各做 5 次，動作要慢、上半身不要跟著轉。', fig: 'hipgate', cap: '膝蓋抬到 90 度，往外打開，再慢慢放下，就像打開一扇門。' },
      { mins: 2, cat: 'Practice Swing', name: '半揮空揮：刷草', how: '用 PW 從 9 點到 3 點空揮 10 次，每一次都讓桿頭輕輕刷過草皮（或打擊墊）的同一個位置。', lesson: 'iron-basics', fig: 'brush', cap: '刷到的位置要一樣，代表擊球的最低點很穩定。' },
      { mins: 2, cat: 'Practice Swing', name: '全揮空揮：慢慢加速', how: '換 7 號鐵空揮 10 次：前 3 次用 50% 力量，接著 4 次 70%，最後 3 次正常速度。每次收桿都站穩 3 秒。', lesson: 'finish-tempo', fig: 'build', cap: '速度一段一段加上去，最後幾次才用正常速度。' }
    ]
  };

  /* Driving-range plans for full-swing practice. */
  /* For complete beginners: small swings first, then build up. */
  GL.plans.b40 = {
    name: 'Beginner Range Session', zh: '新手練習場 40 分鐘',
    why: {
      title: '給初學者的練習原則',
      intro: '剛開始去練習場，最重要的不是打多遠，而是每一顆都打得到球。這份菜單從很小的擺幅開始，一步一步加大，比較不會越打越亂。',
      items: [
        ['先求打到，再求打遠', '球飛多遠不重要，桿頭每次都紮實碰到球才是重點。'],
        ['從小擺幅開始', '擺幅越小越容易控制。小揮桿打穩了，再慢慢加大。'],
        ['每 5 顆檢查一次準備動作', '握桿、站姿、姿勢、瞄準，常常打著打著就跑掉了。'],
        ['累了就停', '手開始痠、動作開始亂，就休息一下或提早結束，硬打只會練出壞習慣。']
      ],
      tip: '每一項都要連續 3 顆打得紮實，再進到下一項；做不到就留在這一項多打幾顆。'
    },
    blocks: [
      { mins: 8, cat: 'Half Swing', name: '小擺幅：Tee 上的 PW', how: '把球放在很低的 Tee 上，用 PW 做小擺幅：後擺左手臂到 7 點半，收桿到 4 點半，打 15 顆。桿頭紮實碰到球就算成功，不用管飛多遠。', lesson: 'grip', fig: 'clock', cap: '先用最短的 7 點半擺幅，打穩了再加大。' },
      { mins: 10, cat: 'Half Swing', name: 'PW 半揮：9 點到 3 點', how: '把球從 Tee 上拿下來，直接放在打擊墊上。用 PW 打 20 顆 9 點到 3 點的半揮，記下 20 顆裡有幾顆打得紮實。', lesson: 'stance', fig: 'halfswing', cap: '後擺左手臂到 9 點，收桿到 3 點，兩邊一樣長。' },
      { mins: 6, cat: 'Setup', name: '準備動作檢查', how: '地上放一支球桿指向目標。每打 5 顆球，就從頭做一次完整的準備動作：握桿、站姿、姿勢、瞄準，再打下一顆。', lesson: 'alignment', fig: 'aimline', cap: '用地上的球桿確認腳、髖、肩都和目標線平行。' },
      { mins: 10, cat: 'Full Swing', name: '7 號鐵四分之三揮桿', how: '換 7 號鐵，用 70% 力量做 10 點到 2 點的揮桿，打 15 顆。每一顆都選一個目標旗，收桿站穩 3 秒。', lesson: 'posture', fig: 'targets', cap: '不用全力，揮得穩比揮得快重要。' },
      { mins: 6, cat: 'Half Swing', name: '短距離收尾：PW 小擺幅', how: '換回 PW，用 8 點到 4 點的擺幅打 10 顆，瞄打位前方最近的旗子，練習打短距離。', fig: 'clock', cap: '擺幅越小、飛得越近，最後用小擺幅打穩收尾。' }
    ]
  };
  /* Putting-only plan. */
  GL.plans.p30 = {
    name: 'Complete Putting', zh: '推桿 30 分鐘',
    blocks: [
      { mins: 3, cat: 'Putting', name: 'Gate Drill', how: '1 公尺推 10 顆，找回推桿頭方正的感覺。', lesson: 'short-putts', fig: 'gate', cap: '兩支 tee 的間距只比球寬一點，球要從中間穿過。' },
      { mins: 9, cat: 'Putting', name: 'Circle Drill', how: '洞周圍 1 公尺放 8 顆，全部連續推進才能退到 1.5 公尺。', lesson: 'short-putts', fig: 'circle', cap: '以洞為中心，在 1 公尺處插 8 支 tee 圍成一圈，每支 tee 旁放一顆球。' },
      { mins: 9, cat: 'Putting', name: 'Lag Ladder', how: '10、15、20 步各插一支 tee，每一顆都要比上一顆遠，但不能超過 20 步。', lesson: 'lag-putting', fig: 'ladder', cap: '練的是距離感，方向偏一點沒關係。' },
      { mins: 9, cat: 'Pressure', name: 'Par 18 推桿小遊戲', how: '在練習果嶺選 9 個洞、各種距離和坡度，每洞標準桿 2。新手先以 22 桿以內為目標。', lesson: 'green-reading', fig: 'par18', cap: '每洞只推一顆球，像真的下場一樣認真看線，最後加總桿數。' }
    ]
  };

  /* Chipping-only plan. */
  GL.plans.c30 = {
    name: 'Chipping Session', zh: '切球 30 分鐘',
    blocks: [
      { mins: 8, cat: 'Chipping', name: '毛巾落點：Bump & Run', how: '把毛巾鋪在果嶺邊緣往內一步，用 9 號鐵或 PW 打 15 顆，每一顆都要先落在毛巾上再滾向洞。', lesson: 'bump-and-run', fig: 'towel', cap: '把毛巾鋪在果嶺邊緣往內一步，球要先落在毛巾上，再滾向洞。' },
      { mins: 9, cat: 'Chipping', name: '三支桿比較', how: '7 號鐵、9 號鐵、PW 各打 5 顆到同一個落點，記下每支桿落地後滾多遠。', lesson: 'bump-and-run', fig: 'threeclub', cap: '三支桿都打到同一條毛巾上，觀察球滾多遠：PW 最短、7 號鐵最長。' },
      { mins: 7, cat: 'Chipping', name: '停在一支推桿內', how: '從果嶺邊不同位置切 10 顆，目標是停在洞周圍一支推桿長度的圈裡，這樣下一推就很好進。', lesson: 'standard-chip', fig: 'chipzone', cap: '用一支推桿長度當半徑，在洞周圍想像一個圈，球停在圈裡就成功。' },
      { mins: 6, cat: 'Pressure', name: 'Up & Down 挑戰', how: '選長草、邊緣、沙坑旁 3 個位置，每個位置切一次、推一次，兩桿內進洞才過關。', lesson: 'standard-chip', fig: 'updown', cap: '每個位置只打一顆球，像真的下場一樣認真打。' }
    ]
  };

  GL.plans.r60 = {
    name: 'Complete Range Session', zh: '練習場 60 分鐘',
    blocks: [
      { mins: 10, cat: 'Half Swing', name: '短鐵半揮', how: 'PW 與 9 號鐵各打 10 顆半揮，檢查擊球點。', lesson: 'iron-basics', fig: 'targets', cap: '選最近的旗子當目標，先求每一顆都紮實打到。' },
      { mins: 20, cat: 'Full Swing', name: '7 號鐵目標練習', how: '每顆都換一個目標，記錄 20 顆中有幾顆落在目標附近。', lesson: 'alignment', fig: 'targets', cap: '每球都用球桿擺出瞄準線，再換目標。' },
      { mins: 10, cat: 'Woods', name: 'Hybrid 或 5 號木', how: '用 75% 的力量打 10 顆，球放在很低的 Tee 上或直接放在打擊墊上，收桿站穩 3 秒。', fig: 'tee', cap: 'Tee 的高度：球有一半在桿頭上方。' },
      { mins: 10, cat: 'Driver', name: '開球', how: '用 Driver 或 5 號木以 75% 力量打 10 顆，想像兩側是球道邊界。', lesson: 'driver-basics', fig: 'tee', cap: 'Tee 的高度：球有一半在桿頭上方。' },
      { mins: 10, cat: 'Half Swing', name: '挖起桿距離控制', how: '在打位上用 PW 瞄最近的旗子，用 8 點和 9 點兩種擺幅各打 10 顆，記下每種擺幅大概飛多遠。', fig: 'clock', cap: '擺幅越小、飛得越近；用固定的擺幅來控制距離。' }
    ]
  };
})(window.GL);
